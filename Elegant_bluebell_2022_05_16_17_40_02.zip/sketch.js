let bg;
let y = 0

function setup() {
  createCanvas(400, 400);
  colorMode(HSB);
  
    img = loadImage('images/skysunset.jpg');
 
}

function draw() {
  background(220);
  stroke(0);
 image(img, 0, 0);
  // bg = loadImage('assets/sunsetsky.jpg');
  
 // fill(255,255,50); 
//  ellipse(mouseX,mouseY, 75,75 ); 
//   rect(300, 250, 20, 20);
//   triangle(280,250, 310,220, 340,250);
//   triangle(280,235, 310,205, 340,235);
  
//   rect(23, 250, 20, 20);
// triangle(5 , 250, 33, 200, 61, 250);
//    triangle(5,230, 33, 190, 61, 230);
if(mouseX < width/2){
  fill(map(mouseX,0,width/2,50,25,1),255,255);
}
  else{  fill(25,255,map(mouseX,width/2,width,255,0,1));
  }
  ellipse(mouseX, mouseY,75,75);
  
  c = color('#228B22');
  fill(c);
rect(width/100, 2 * height/3 , 390, 199);
  
  c=color('brown')
  fill(c)
  rect(23, 250, 20, 20);
  rect(300, 250, 20, 20);
 
  c = color('#228B22');
  fill(c);
  triangle(280,250, 310,220, 340,250);
  triangle(280,235, 310,205, 340,235);
  
triangle(5 , 250, 33, 200, 61, 250);
   triangle(5,230, 33, 190, 61, 230);
  
  
}